
public interface Item {
	
	public int getItemNumber();

	public double getUnitPrice();
	
	public String getDescription();
	
	public int getQuantity();
	
	public void setQuantity(int newQuantity);
	
}
