import java.util.*;
import java.util.ArrayList;
public class ShoppingCart implements Cart {

	public void addItem(SelectedItem newItem) {
       for (newItem.equals(itemDescription)){
    	   Quantity = Quantity + 1;
       }else {
    	   return new item;
       }
	}
	public void deleteItem(int deleteItemNumber) {
		deleteItemnumber = getItemNumber;
		setItemNumber = 0;
	}

	
	public double getTotal() {
	getQuantity();
		return Quantity;
	}

	
	public double getTax() {
		getTax()
		return Tax;
	}

	
	public double getShipping() {
		
		return 0;
	}

}
